﻿namespace ICEP.Models
{
    public enum Dept
    {
        ComputerScience,
        ComputerSystemsEngineering,
        Informatics,
        InformationTechnology
    }
}