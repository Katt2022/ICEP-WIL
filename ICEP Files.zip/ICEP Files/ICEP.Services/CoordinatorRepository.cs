﻿using ICEP.Models;
using System.Linq;

namespace ICEP.Services
{
    public class CoordinatorRepository : ICoordinatorRepository
    {


        private List<Coordinator> _codsList;


        public CoordinatorRepository()
        {
            _codsList = new List<Coordinator>()
           {
               new Coordinator(){Id = 1, LastName = "Spies", Name="John", Email = "spiesj@tut.ac.za", Building = "19", Department = Dept.ComputerScience},
               new Coordinator(){Id = 2, LastName = "Ramohlala", Name="Sbusiso", Email = "ramohlala@tut.ac.za", Building = "20", Department = Dept.InformationTechnology},
               new Coordinator(){Id = 3, LastName = "Mabunda",Name="Alpfred", Email = "mabunda@tut.ac.za", Building = "10", Department = Dept.Informatics},
               new Coordinator(){Id = 4, LastName = "Baloyi",Name="Tshepiso", Email = "baloyi@tut.ac.za", Building = "14", Department = Dept.ComputerSystemsEngineering},
               new Coordinator(){Id = 4, LastName = "Tshabalala",Name="SM", Email = "tshabalala@tut.ac.za", Building = "14", Department = Dept.ComputerSystemsEngineering},
               new Coordinator(){Id = 4, LastName = "Stones",Name="KP", Email = "stones@tut.ac.za", Building = "14", Department = Dept.Informatics},
               new Coordinator(){Id = 4, LastName = "Smith",Name="PR", Email = "smith@tut.ac.za", Building = "14", Department = Dept.ComputerScience},

           };
        }
        public IEnumerable<Coordinator> Search(string searchTerm)
        {
            if (string.IsNullOrEmpty(searchTerm))
            {
                return _codsList;
            }
            return _codsList.Where(
                c => c.Name.Contains(searchTerm)  || 
                c.Department.ToString().Contains(searchTerm) ||
                 c.LastName.Contains(searchTerm) ||
                 c.Email.Contains(searchTerm) ||
                 c.Building.Contains(searchTerm)
                 );

           
        }

        public IEnumerable<Coordinator> GetAllCoordinators()
        {
            
            return _codsList;
        }
        public Coordinator GetCoordinator(int id) {
            return _codsList.FirstOrDefault(e => e.Id == id)!;
        }
    }
}