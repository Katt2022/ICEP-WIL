﻿using ICEP.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ICEP.Services
{
    public  interface ICoordinatorRepository
    {
        IEnumerable<Coordinator> Search(string searchterm);
        IEnumerable<Coordinator> GetAllCoordinators();
        Coordinator GetCoordinator(int id);
    }
}
