using ICEP.Models;
using ICEP.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ICEPWILL.Pages.Cod
{
    public class CodDetailsModel : PageModel
    {
        private readonly ICoordinatorRepository coordinatorRepository;

        public CodDetailsModel(ICoordinatorRepository coordinatorRepository)
        {
            this.coordinatorRepository = coordinatorRepository;
        }

        public Coordinator CoordinatorGet { get; private set; }

        public void OnGet(int id)
        {
            CoordinatorGet = coordinatorRepository.GetCoordinator(id);
        }
    }
}
