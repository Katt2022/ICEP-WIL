using ICEP.Models;
using ICEP.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ICEPWILL.Pages.Cod
{
    public class IndexModel : PageModel
    {
        private readonly ICoordinatorRepository coordinatorRepository;
        public IEnumerable<Coordinator> CoordinatorsList { get; set; }

        [BindProperty(SupportsGet = true)]
        public string SearchTerm { get; set; }

        public IndexModel(ICoordinatorRepository coordinatorRepository)
        {
            this.coordinatorRepository = coordinatorRepository;
        }
        
        public void OnGet()
        {
            CoordinatorsList = coordinatorRepository.Search(SearchTerm);
        }
    }
}
