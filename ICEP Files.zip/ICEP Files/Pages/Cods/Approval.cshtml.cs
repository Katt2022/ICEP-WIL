using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ICEPWILL.Pages.Cods
{
    public class ApprovalModel : PageModel
    {
        public void OnGet()
        {
        }
        public void OnPost()
        {
            Response.Redirect("/Cods/Verify");
        }
    }
}
