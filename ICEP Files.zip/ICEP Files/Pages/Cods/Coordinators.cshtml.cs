using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;

namespace ICEPWILL.Pages
{
    public class CoordinatorsModel : PageModel
    {
        public List<CoordinatorInfo> listCods = new List<CoordinatorInfo>();
        public void OnGet()
        {
            try
            {

                string connString = "Data Source=.\\sqlexpress;Initial Catalog=ICEPDATA;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connString))
                {
                    connection.Open();
                    string sql = "Select * from Coordinators";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                CoordinatorInfo codInfo = new CoordinatorInfo();
                                codInfo.id = "" + reader.GetInt32(0);
                                codInfo.name = reader.GetString(1);
                                codInfo.email = reader.GetString(2);
                                codInfo.building = reader.GetString(3);
                                codInfo.dept = reader.GetString(4);

                                listCods.Add(codInfo);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception " + ex.ToString);
            }
        }


    }
    public class CoordinatorInfo
    {
        public string id;
        public string name;
        public string email;
        public string building;
        public string dept; 

    }
}
