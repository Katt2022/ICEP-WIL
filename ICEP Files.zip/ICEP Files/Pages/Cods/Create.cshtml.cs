using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;

namespace ICEPWILL.Pages.Cods
{
    public class CreateModel : PageModel
    {
        public CoordinatorInfo coordinatorInfo = new CoordinatorInfo();
        public string errmesasage = "";
        public string succmesasage = "";
        public void OnGet()
        {
        }

        public void OnPost()
        {
            coordinatorInfo.name = Request.Form["name"];
            coordinatorInfo.email = Request.Form["email"];
            coordinatorInfo.building = Request.Form["building"];
            coordinatorInfo.dept = Request.Form["dept"];

            if (
                coordinatorInfo.name == "" ||
                coordinatorInfo.email == "" ||
                coordinatorInfo.dept == "" ||
                coordinatorInfo.building == ""


                )
            {
                errmesasage = "All fields are required";
                return;
            }

            //save to db
            try
            {
                string connString = "Data Source=.\\sqlexpress;Initial Catalog=ICEPDATA;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connString))
                {
                    connection.Open();
                    string sql = "insert into Coordinators (cod_name, email, building, dept) values (@name, @email, @building, @dept);";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {

                        command.Parameters.AddWithValue("@name", coordinatorInfo.name);
                        command.Parameters.AddWithValue("@email", coordinatorInfo.email);
                        command.Parameters.AddWithValue("@building", coordinatorInfo.building);
                        command.Parameters.AddWithValue("@dept", coordinatorInfo.dept);

                        command.ExecuteNonQuery();
                    }
                }

            }

            catch (Exception ex)
            {
                errmesasage = ex.Message;
                return;
            }
           
         
        coordinatorInfo.name = "";
            coordinatorInfo.email = "";
            coordinatorInfo.dept = "";
            coordinatorInfo.building = "";
            succmesasage = "New Coordinator added";
            Response.Redirect("Coordinators");
        }
        

    }

}
