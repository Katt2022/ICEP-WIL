using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ICEPWILL.Pages.Cods
{
    public class DeniedModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
