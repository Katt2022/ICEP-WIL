using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ICEPWILL.Pages.Cods
{
    public class ViewModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
